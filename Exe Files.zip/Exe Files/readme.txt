WASD - Controls Movement
J - Shooting Animation (No bullets yet)
K - Jump
R - Restart Level
Esc - Quit

Avoid radioactive goo and flying chickens to make it to the exit of the level.